# stripebot
It is a stripe checker cc bot for telegram
